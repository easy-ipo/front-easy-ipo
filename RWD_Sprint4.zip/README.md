# Challenge Sprint 3

## Responsive Web Development

**Professor**: Adriano Kleber Milanez

### Integrantes do Grupo

- RM 97439 - Ricardo Rubio Sito Antunes
- RM 97012 - Igor Augusto Takeshigue Lemos
- RM 97282 - Pablo Lage Carral
- RM 97192 - Joederson Oliveira Pereira
- RM 96950 - Mário Ito Bocchini
